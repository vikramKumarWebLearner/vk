let computerGuess;
let userGuess=[];
let userGuessUpdate =document.getElementById('textouput');
let userNumberUpdate = document.getElementById('input');
let audio = new Audio("./audio/pda.mp3");
const init = () => {
	computerGuess = Math.floor(Math.random() * 100);
    document.getElementById('newGame').style.display="none";
   document.getElementById('gamearea').style.display="none";

};

  const startGame = () =>{
  	document.getElementById('welcome').style.display="none";
    document.getElementById('gamearea').style.display="block";

  };
  //reload page
  const newGameBegin = () =>{
  	window.location.reload();
  };

  //sart new game
  const startNewGame = () =>{
  	audio.play();
  	document.getElementById('newGame').style.display="inline";
    userNumberUpdate.setAttribute("disabled",true);
  };
// main logic of app

const compareGuess = () => {
	audio.play();
	const userNumber = Number(document.getElementById('input').value);
      userGuess=[...userGuess,userNumber];
      document.getElementById('guesses').innerHTML= userGuess;
       //check value is low and high

      if(userGuess.length < maxGuess) {
       if (userNumber > computerGuess) {
       	userGuessUpdate.innerHTML="Your guess is high 😯";
        userNumberUpdate.value="";
       }
       else if(userNumber < computerGuess){
      userGuessUpdate.innerHTML="Your guess is low 😞";
          userNumberUpdate.value="";
       }
       else{
       	userGuessUpdate.innerHTML="It's Correct 🙂";
            userNumberUpdate.value=" ";
            startNewGame(); 
       }
   }
       else{
       	if (userNumber > computerGuess) {
       	userGuessUpdate.innerHTML=`Your Loose!! Correct number was {compareGuess}`;
        userNumberUpdate.value="";
        startNewGame();
       }
       else if(userNumber < computerGuess){
      userGuessUpdate.innerHTML=`Your Loose!! Correct number was {compareGuess}`;
          userNumberUpdate.value=" ";
          startNewGame();
       }
       else{
       	userGuessUpdate.innerHTML="It's Correct 🙂";
            userNumberUpdate.value=" ";
            startNewGame(); 
       }

       }
   
       document.getElementById('attempts').innerHTML= userGuess.length;
};

const easymode = () => {
	audio.play();
	maxGuess=10;
    startGame();
};


const hardmode = () => {
	audio.play();
	maxGuess=5;
    startGame();	
};